<?php 

require 'connection.php';


class DowGroup {



}
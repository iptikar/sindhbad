<<<<<<< HEAD
<?php 

$a = ['a', 'b'];
$c = ['c', 'd'];

$e = array_merge($a, $c);

echo "<pre>";
print_R($e);
echo "<pre>";
=======
<?php

echo "<pre>";

print_r($_SERVER);
echo "</pre>";
>>>>>>> 5d8c4809778abca623285086c9c8e91046f04d18

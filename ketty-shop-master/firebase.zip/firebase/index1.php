<!DOCTYPE html>
<html>
<head>
	<title>Firebase test</title>
</head>

<body>

</body>

<script src="https://www.gstatic.com/firebasejs/4.3.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBs5WGqQfFNsQcl6SWYAabpHwbL8Vl3nEk",
    authDomain: "newproject-10d05.firebaseapp.com",
    databaseURL: "https://newproject-10d05.firebaseio.com",
    projectId: "newproject-10d05",
    storageBucket: "newproject-10d05.appspot.com",
    messagingSenderId: "619180276218"
  };
  firebase.initializeApp(config);
</script>
</html>
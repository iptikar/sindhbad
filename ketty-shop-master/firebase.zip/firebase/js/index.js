
var submitBtn =  document.getElementById("submitBtn"); 

function submitClick()
{
	// Get random numbers 
	var userId = Math.floor(Math.random() * 100);
	
	var firebaseRef = firebase.database().ref('users/');
	
	var mainText = document.getElementById("mainText").value;
	
	//firebaseRef.set(mainText);
	var name = "Jhonny";
	var email = 'jhonny@gmail.com';
	var imageUrl = 'http://localhost/';
	var id = userId;
	
	writeUserData(userId, name, email,imageUrl,id);
	
	
}


function getRandomArbitrary(min, max) 
{
    return Math.random() * (max - min) + min;
}


function writeUserData(userId, name, email,imageUrl,id) 
{
  firebase.database().ref('users/' + userId).set({
    username: name,
    email: email,
    profile_picture : imageUrl,
    id:userId
  });
}

// Function for updating data 
function ReadData()
{

	var heading = '<h1>This is my users</h1>';
	var data = '';
	var leadsRef = firebase.database().ref('users/');
	
	leadsRef.on('value', function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      var childData = childSnapshot.val();
      //alert(childData.username);
    var data = '<th scope="row">'+childData.id+'</th> <td>'+childData.username+'</td> <td>'+childData.email+'</td> <td><p data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs" data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></p></td><td><p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p></td>';
   //	var newdata = heading.concat(data);
    
    
    var div = document.createElement('tr');

	
	
    

    div.innerHTML = data;

	
    document.getElementById('dymic-data').appendChild(div);
    
    });
    


 
});



	
 
	
}
  	
function RemoveData(uid)
{
	// Get random numbers 
	var userId = 57;
	
	var firebaseRef = firebase.database().ref('users/'+userId);
	
	firebaseRef.remove();
}

function writeNewPost() {
  // A post entry.
  /* We have these data to update */
  /*
   	username: name,
    email: email,
    profile_picture : imageUrl,
    id:userId
  */
  
  /* get the new data */
  var username = 'Krikhelmat';
  var email = 'krik@gmail.com';
  var id = 56;
 
  
  var profile_picture = 'http://localhost/{id}/picture/krik';
 
  var postData = {
    username: username,
    email: email,
    profile_picture: profile_picture,
    id: id
  };

	// Get a key for a new Post.
  var newPostKey = firebase.database().ref().child('users').push().key;
  
  // Write the new post's data simultaneously in the posts list and the user's post list.
  var updates = {};
  //updates['/users/' + newPostKey] = postData;
  updates['/users/' + id] = postData;

  return firebase.database().ref().update(updates);
  
  alert('updated');

}

function UploadFile()
{
	// Create a root reference
	var storageRef = firebase.storage().ref();

	// Create a reference to 'mountains.jpg'
	var mountainsRef = storageRef.child('fifa.jpg');

	// Create a reference to 'images/mountains.jpg'
	var mountainImagesRef = storageRef.child('fifa.jpg');

	// While the file names are the same, the references point to different files
	mountainsRef.name === mountainImagesRef.name            // true
	
	mountainsRef.fullPath === mountainImagesRef.fullPath    // false
	
}

function UploadFileFirebase()
{

	var fileButton = document.getElementById("fileButton");
    fileButton.addEventListener('change', function(e){
    
    
                 var file = e.target.files[0];
                
                var storageRef = firebase.storage().ref().child(file.name);
                
                // Store reference 2
                 var storageRef1 = firebase.storage().ref().child('images/'+file.name);
                  
                storageRef.name = storageRef1.name;
                storageRef.fullPath = storageRef1.fullPath;
                
                
                storageRef.put(file);
                  
                  alert('file saved');
              }); 
}

<!DOCTYPE html>
<html>
<head>
	<title>Firebase test</title>
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,700" rel="stylesheet">

	<script src="https://use.fontawesome.com/939e9dd52c.js"></script>

	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

	<div class="mainDiv" align="right">
		<h1 align="left">Firebase Web App</h1>
		<textarea id = "mainText" placeholder="Enter text here..."></textarea>
		<button id = "submitBtn" onClick = "submitClick();"><i class="fa fa-arrow-right" aria-hidden="true"></i></button>		
	</div>

</body>


<script src="https://www.gstatic.com/firebasejs/4.3.1/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBs5WGqQfFNsQcl6SWYAabpHwbL8Vl3nEk",
    authDomain: "newproject-10d05.firebaseapp.com",
    databaseURL: "https://newproject-10d05.firebaseio.com",
    projectId: "newproject-10d05",
    storageBucket: "newproject-10d05.appspot.com",
    messagingSenderId: "619180276218"
  };
  firebase.initializeApp(config);
</script>


<script src = "js/index.js"></script>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>Firebase test</title>
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,700" rel="stylesheet">

	<script src="https://use.fontawesome.com/939e9dd52c.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	

	<style> 
	.users {
		list-style:None;
		
	}
	</style>
</head>

<body>

<div class = "col-md-4"></div>

<div class = "col-md-4">
<div class = "users-register">
	<div id = "get-users">
		<table class="table">
  <thead>
    <tr>
      <th>Id</th>
      <th>First Name</th>
      <th>Email</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr>
  </thead>
  
  <tbody id = "dymic-data">
    
    
  </tbody>
</table>
	</div>
</div>

</div>

<div class = "col-md-4"></div>

<input id = "fileButton" type = "file" multiple/>
</body>


<script src="https://www.gstatic.com/firebasejs/4.3.1/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBs5WGqQfFNsQcl6SWYAabpHwbL8Vl3nEk",
    authDomain: "newproject-10d05.firebaseapp.com",
    databaseURL: "https://newproject-10d05.firebaseio.com",
    projectId: "newproject-10d05",
    storageBucket: "newproject-10d05.appspot.com",
    messagingSenderId: "619180276218"
  };
  firebase.initializeApp(config);
</script>


<script src = "js/index.js"></script>
<script type = "text/javascript">
window.onload = function (){
ReadData();
//RemoveData();
//writeNewPost();
UploadFileFirebase();
};
</script>
</html>
<?php

session_start();

$_SESSION['closed_at'] = time();

<?php
require('fetch-chat.php');
echo fetchUsersList();
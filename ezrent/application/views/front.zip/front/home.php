<div class="bannerSec">
  <div id="bannerSldier" class="bannerSlider">
    <?php foreach($slider as $val){ ?>
    <div class="item">
      <div class="banIn"><img src="uploads/fleet/700x417/<?=$val['picture_offer']?>" alt="EZ Rent a Car - Car Rental, Car Leasing Dubai, UAE" />
        <div class="bannerCaption">
          <h4 class="bannerText1">
            <?=$val['title']?>
          </h4>
          <h3 class="bannerText2"><span class="uppercaseTxt">
            <?=$val['daily_offer_details']?>
            </span> per day</h3>
          <span class="bookNow"><a href="<?=route_to('fleet/booking/'.$val['id_fleet'])?>">Book Now<i></i></a></span> </div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>
<div class="main">
  <div class="block">
    <div class="mainWrap clearfix">
      <?php $this->load->view('front/booking-search'); ?>
    </div>
  </div>
  <div class="block welcomePart">
    <div class="mainWrap clearfix">
      <div class="welComeLt leftCls">
        <h1>Welcome to EZ Rent A Car</h1>
        <?=$about->description?>
      </div>
      <?php $this->load->view('front/newsletter-box'); ?>
    </div>
  </div>
  <div class="block clearfix">
    <div class="filter fleets homePage clearfix">
      <h2 class="titleName noLine"> Our Fleet</h2>
      <div class="mainWrap clearfix">
        <div class="filtOption text-center">
          <ul class="vendors">
            <li id="allcars">
              <button class="btn btn-xs btn-primary product-button">All Cars</button>
            </li>
            <?php foreach($categories as $val){ ?>
            <li id="<?=$val['title']?>">
              <button class="btn btn-xs btn-primary product-button">
              <?=$val['title']?>
              </button>
            </li>
            <?php } ?>
          </ul>
        </div>
        <div class="filtBox clearfix">
          <div class="product-carousel">
            <?php foreach($fleet as $val){?>
            <div class="filter-allcars filter-<?=$val['category_title']?> item">
              <div class="fleetBox">
                <div class="fleetUp"> <a href="<?=route_to('fleet/details/'.$val['id_fleet'])?>">
                
                  <?php if(!empty($val['picture'])){ ?>
                  <img src="uploads/fleet/255x127/<?=$val['picture']?>" alt="EZ Rent a Car - Car Rental, Car Leasing Dubai, UAE" />
                  <?php } ?>
                  <?php if(empty($val['picture'])){ ?>
                  <img src="images/front/logo1.png" alt="EZ Rent a Car - Car Rental, Car Leasing Dubai, UAE" />
                  <?php } ?>              
                
                </a> </div>
                <div class="fleetDw">
                  <h3><a href="<?=route_to('fleet/details/'.$val['id_fleet'])?>">
                    <?=$val['title']?>
                    </a></h3>
                  <div class="fleeDiv"><!--<span class="uppercaseTxt">
                    <?=$val['daily_cost']?>
                    </span> per day--> </div>
                  <div class="bookBtn"> <a href="<?=route_to('fleet/booking/'.$val['id_fleet'])?>">Book Now</a> </div>
                </div>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="block clearfix homeBlock">
    <div class="mainWrap clearfix">
      <div class="nwsBtm">
        <h3 class="text-center">Our Blog</h3>
        <div class="nwsBox postSldier1 clearfix">
          <?php foreach($blog as $val){
					$date = new DateTime($val['blog_date']);
			?>
          <div>
            <div class="imgDiv"><a href="<?=route_to('blog/details/'.$val['id_blog'])?>"><img src="uploads/blog/354x188/<?=$val['picture']?>" alt="ez blog" /></a></div>
            <?php if($val['blog_date']!='0000-00-00'){ ?>
            <span>
            <?=$date->format('M d, Y')?>
            </span>
            <?php } ?>
            <h4>
              <a href="<?=route_to('blog/details/'.$val['id_blog'])?>"><?=$val['title']?></a>
            </h4>
            <p><?=strip_tags(character_limiter($val['description'],150))?></p>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</div>
